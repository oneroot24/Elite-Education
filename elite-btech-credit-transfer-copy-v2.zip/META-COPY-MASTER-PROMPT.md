# ELITE EDUCATION — META ADS LANDING PAGE COPY MASTER PROMPT

Act as a senior conversion copywriter, UX writer, Meta Ads strategist and landing-page CRO specialist with 10+ years of experience. Rewrite and improve the Elite Education landing page for a Meta Ads campaign focused exclusively on B.Tech Credit Transfer.

## Source of truth
Use the supplied BTech Credit Transfer.pdf as the primary content source. It supports: students who completed some B.Tech semesters; discontinued B.Tech; backlogs/failed subjects; study at another university/institution; possible use of eligible previous credits; document submission; credit evaluation; eligibility verification; university approval; continuation; B.Tech branches including Civil Engineering, Mechanical Engineering, Fire & Safety, Computer Science Engineering and Lateral Entry; and limitations around approval, credit acceptance, syllabus matching and repeating subjects/semesters.

Do not invent university names, approval status, placement numbers, salary figures, success rates, testimonials, guarantees or accreditation claims. The source notes mention UGC, AICTE, PCI, BCI, AIU, WES and MEA; do not turn these into blanket advertising claims without exact programme/university verification.

## Audience
Write for an Indian B.Tech student thinking: “I stopped my B.Tech. Can I continue?”, “I have backlogs. What can I do?”, “I studied at another university. Are my credits useful?”, or “Do I need to start from zero?”

## Conversion goal
Primary: qualified eligibility enquiry. Secondary: WhatsApp conversation. Primary CTA: CHECK MY B.TECH ELIGIBILITY. Secondary CTA: TALK TO A COUNSELLOR ON WHATSAPP.

## Copy rules
- Make every headline understandable in 2–3 seconds.
- Start with the student’s problem, not company language.
- Use simple, natural Indian English.
- Prefer short sentences and concrete words.
- Use conditional language: may, can be evaluated, subject to university approval.
- Never promise transfer, admission, degree recognition, jobs, salary or overseas acceptance.
- Avoid generic phrases such as “holistic solutions”, “seamless journey”, “empowering futures” and “end-to-end excellence”.
- Do not repeat “credit transfer” unnaturally in every section.
- Keep the emotional tone hopeful but credible.
- Every section should move the visitor toward eligibility enquiry or WhatsApp.
- Keep mobile readability as the priority.

## Required copy direction
Hero: “Stopped your B.Tech? Let’s check if you can continue.”
Support: mention backlogs, stopped midway, another university and previous credits immediately.
Form: “Could your previous B.Tech credits still help?” with a simple explanation of the 2-step check.
Audience: “If your B.Tech stopped, start here.”
Cards: Stopped midway / Have backlogs / Studied elsewhere / Completed semesters.
Explanation: “Your completed subjects may not have to be lost.” Then clearly explain that acceptance depends on the university and academic record.
Process: “No guesswork. Your academic record comes first.” Steps: Share your records / Review your credits / Check eligibility / Get university approval / Continue your B.Tech.
Programmes: keep the campaign B.Tech-focused; do not distract with unrelated programme categories.
FAQ: use real student questions about possibility, partial transfer, documents, universities and guarantees.
Final CTA: “Find out what your previous B.Tech work may be worth.”

## Meta message match
Ad hooks can include: “Stopped your B.Tech midway?”, “Have B.Tech backlogs?”, “Studied B.Tech at another university?”, “Do you have previous B.Tech credits?” The landing page should immediately answer: “Let’s check if you can continue.”

## Final QA
Confirm that the page is instantly understandable, has one dominant CTA, uses human copy, remains exclusively about B.Tech Credit Transfer, avoids unsupported claims, and makes the next action obvious.
