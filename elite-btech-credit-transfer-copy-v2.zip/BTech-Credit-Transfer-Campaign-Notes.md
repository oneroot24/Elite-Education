# Campaign Notes Based on Supplied BTech Credit Transfer Brief

The supplied material describes credit transfer as a possible way for eligible students to continue B.Tech by transferring credits earned from previously completed subjects/courses to another institution or eligible programme.

Audience situations in the brief:
- completed some semesters
- discontinued B.Tech
- failed subjects/backlogs
- studied B.Tech at another university/institution
- completed eligible subjects and want to continue

Process described:
1. Submit B.Tech marksheets/transcripts/relevant documents.
2. Evaluate completed subjects, credits, syllabus and academic records.
3. Verify eligibility under university rules.
4. Eligible credits may transfer to a new programme.
5. Continue B.Tech and complete remaining academic requirements.

Programmes listed:
- B.Tech Civil Engineering
- B.Tech Mechanical Engineering
- B.Tech Fire & Safety
- B.Tech Computer Science Engineering
- B.Tech Lateral Entry
- M.Tech Computer Science Engineering
- M.Tech Environmental

Limitations listed:
- transfer depends on university approval
- not all previous credits may be accepted
- course/syllabus matching may be required
- some subjects/semesters may need repeating
- recognition can vary for jobs, higher studies and overseas use

Claim-control note:
The supplied notes reference UGC, AICTE, PCI, BCI, AIU, WES, MEA, MNC jobs and UPSC jobs. These should be independently verified for the exact university/programme before being used as advertising claims.
