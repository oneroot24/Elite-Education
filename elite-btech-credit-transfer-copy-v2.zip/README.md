# Elite Education — B.Tech Credit Transfer Performance Landing Page

This build is designed specifically for a Meta Ads campaign around **B.Tech Credit Transfer**. It uses the supplied campaign brief and Elite Education logo, with a conversion-first structure rather than a generic education landing page.

## Conversion strategy

- Hero message matches the Meta audience: stopped B.Tech / backlogs / previous credits.
- Primary CTA: **Check My Eligibility**.
- Two-step lead form qualifies the enquiry with status, branch, semester, university and last-study year before asking for contact details.
- WhatsApp is a secondary conversion path.
- The page sells **evaluation and clarity**, not guaranteed transfer/admission.
- Mobile sticky CTA is included.
- UTM, gclid and fbclid values are captured with the lead payload.

## Configure

At the top of `index.html`:

```js
window.ELITE_CONFIG={
  WHATSAPP:"919400771970",
  LEAD_ENDPOINT:"",
  META_PIXEL_ID:"YOUR_PIXEL_ID"
};
```

Set `LEAD_ENDPOINT` to your HTTPS webhook/CRM endpoint and replace `YOUR_PIXEL_ID` with the actual Meta Pixel ID.

## Lead payload

The browser submits:
`name`, `phone`, `email`, `status`, `branch`, `semester`, `university`, `lastYear`, UTM fields, `gclid`, `fbclid`, timestamp and page URL.

## Tracking hooks

- Meta: `PageView`, `ViewContent`, `Lead`
- `dataLayer` event names for GTM/GA4
- WhatsApp CTA links

Recommended downstream funnel:
Landing Page View → ViewContent → Form Start → Lead → WhatsApp Contact → Academic Documents Submitted → Eligible → Admission → Enrolled.

## Claim safety

The source material contains references to UGC, AICTE, PCI, BCI, AIU, WES, MEA and employment/recognition outcomes. Those are deliberately **not** used as blanket claims here. Verify each claim for the exact university/programme before publishing ads or adding badges/logos.


## Copy v2
This build applies `META-COPY-MASTER-PROMPT.md`: shorter problem-first headlines, simpler Indian English, stronger Meta Ads message match, a B.Tech-only programme focus and clearer conditional language.
