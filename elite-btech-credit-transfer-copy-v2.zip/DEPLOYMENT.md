# Production Checklist

1. Verify the exact receiving university/programme and all recognition/approval claims.
2. Add privacy policy/consent wording appropriate to your lead workflow.
3. Connect `LEAD_ENDPOINT` and test real CRM delivery.
4. Replace the Meta Pixel placeholder and verify PageView/ViewContent/Lead in Events Manager.
5. Add GA4/GTM through the production tag container and preserve UTMs.
6. Confirm the WhatsApp number `+91 94007 71970` is correct.
7. Test mobile Safari/Chrome, form validation, UTMs, WhatsApp and sticky CTA.
8. Run Lighthouse/PageSpeed and compress the logo if needed.
9. Set up server-side lead validation and duplicate handling before scaling spend.
10. A/B test the headline and CTA after baseline conversion data is collected.
